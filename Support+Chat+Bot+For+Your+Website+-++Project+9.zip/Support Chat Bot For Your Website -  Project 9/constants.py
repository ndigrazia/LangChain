WEBSITE_URL="https://jobs.excelcult.com/wp-sitemap-posts-post-1.xml"
PINECONE_ENVIRONMENT="us-west1-gcp-free"
PINECONE_INDEX="chatbot"